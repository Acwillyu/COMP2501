package ca.comp2501.lab04;

/**
 * Class models a novel with the book title, author and year published
 * @author William Yu, Jesus araujo, Ethan newtown, Jezer Lagman
 * @version 1.0
 */

public class Novel
{
    private final String title;
    private final String authorName;
    private final int    yearPublished;

    /**
     * Constructs the novels.
     * @param title Title of the novels.
     * @param authorName Name of the novels author.
     * @param yearPublished Year the novel was published.
     */
    public Novel(final String title,
                 final String authorName,
                 final int yearPublished)
    {
        this.title = title;
        this.authorName = authorName;
        this.yearPublished = yearPublished;
    }

    /**
     * Gets the title of the novel
     * @return Title of the novel
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * Gets the authors name.
     * @return Author of the novel
     */
    public String getAuthorName()
    {
        return authorName;
    }
    /**
     * Gets the year of when the novel was published
     * @return Year the novel was published
     */
    public int getYearPublished()
    {
        return yearPublished;
    }
}
