package ca.comp2501.lab05;

/**
 * Class models a persons information.
 * @author William Yu, Ethan Newton
 * @version 1.0
 */

class Person
{
    private final String       firstName;
    private final String       lastName;
    private final int          birthYear;
    private final String       isMarried;
    private final double       weightInPounds;
    private final String       highestEducationLevel;
    public static final int    CURRENT_YEAR = 2023;
    public static final String IS_MARRIED = "No";
    public static final String EDUCATION = "High school";
    public static final double LBS_TO_KG = 0.45359237;

    /**
     * Constructor of a person's information and validates their marriage status and education level.
     *
     * @param firstName             Person's first name.
     * @param lastName              Person's last name.
     * @param birthYear             Person's birth year.
     * @param isMarried             Person's marriage status.
     * @param weightInPounds        Person's weight in pounds.
     * @param highestEducationLevel Person's highest level of education.
     */
    public Person(final String firstName,
                  final String lastName,
                  final int    birthYear,
                  final String isMarried,
                  final double weightInPounds,
                  final String highestEducationLevel)
    {
        isValidEducationLevel(highestEducationLevel);
        isValidMarriageStatus(isMarried);

            this.firstName             = firstName;
            this.lastName              = lastName;
            this.birthYear             = birthYear;
            this.isMarried             = isMarried;
            this.weightInPounds        = weightInPounds;
            this.highestEducationLevel = highestEducationLevel;

    }


    /**
     * Overloaded constructor of a persons information and validates their marriage status and education level. Year
     * is set to 2023.
     * @param firstName Person's first name.
     * @param lastName Person's last name.
     * @param isMarried person's marriage status.
     * @param weightInPounds Person's weight in pounds.
     * @param highestEducationLevel Person's highest level of education
     */
    public Person(final String firstName,
                  final String lastName,
                  final String isMarried,
                  final double weightInPounds,
                  final String highestEducationLevel)
    {
        isValidEducationLevel(highestEducationLevel);
        isValidMarriageStatus(isMarried);

            this.firstName             = firstName;
            this.lastName              = lastName;
            this.birthYear             = CURRENT_YEAR;
            this.isMarried             = isMarried;
            this.weightInPounds        = weightInPounds;
            this.highestEducationLevel = highestEducationLevel;
    }

    /**
     * Overloaded constructor of a person's information. Marriage status is "no" meaning not married. Education
     * level is high school. Year is set to 2023.
     * @param firstName Person's first name.
     * @param lastName Person's last name.
     * @param weightInPounds Weight in pounds.
     */
    public Person(final String firstName,
                  final String lastName,
                  final double weightInPounds)
    {
        this.firstName             = firstName;
        this.lastName              = lastName;
        this.birthYear             = CURRENT_YEAR;
        this.isMarried             = IS_MARRIED;
        this.weightInPounds        = weightInPounds;
        this.highestEducationLevel = EDUCATION;

    }

    /**
     *  Gets the person's first name.
     * @return Person's first name.
     */
    public final String getFirstName()
    {
        return firstName;
    }

    /**
     * Gets the person's last name.
     * @return Person's last name.
     */
    public final String getLastName()
    {
        return lastName;
    }

    /**
     * Gets the year they were born.
     * @return Person's birth year
     */
    public final int getBirthYear()
    {
        return birthYear;
    }

    /**
     * Gets the person's marriage status as "divorced", "married", or "single".
     * @param isMarried Determines if the person is married or not.
     * @return Gets the persons marriage status.
     */
    public final String getIsMarried(final String isMarried)
    {
        if(isMarried.equalsIgnoreCase("yes"))
        {
            return "Married";
        }
        else if(isMarried.equalsIgnoreCase("no"))
        {
            return "single";
        }
        else return "divorced";
    }

    /**
     * Gets the persons weight in pounds.
     * @return Persons weight in pounds.
     */
    public final double getWeightInPounds()
    {
        return weightInPounds;
    }

    /**
     * Gets the persons level of education completed.
     * @return Persons level of education.
     */
    public final String getHighestEducationLevel()
    {
        return highestEducationLevel;
    }

    /**
     * Checks if the persons education level is "high school" , "undergraduate", or "graduate".
     * @param highestEducationLevel Persons level of education.
     * @throws IllegalArgumentException Throws error if none of the options are entered.
     * @return Person's education or the throw.
     */
    private boolean isValidEducationLevel(final String highestEducationLevel)
    {
        if(highestEducationLevel.equalsIgnoreCase("high school") |
           highestEducationLevel.equalsIgnoreCase("undergraduate") |
           highestEducationLevel.equalsIgnoreCase("graduate"))
        {
            return true;
        }
        else
        {
            throw new IllegalArgumentException(("Education level is invalid"));
        }
    }

    /**
     * Checks if the persons married as "yes", no for not married, or divorced.
     * @param  isMarried Person's marriage status
     * @throws IllegalArgumentException Throws error if none of the options are entered.
     * @return Person's marriage status or the throw.
     */
    private boolean isValidMarriageStatus(final String isMarried)
    {
        if(isMarried.equalsIgnoreCase("yes") |
           isMarried.equalsIgnoreCase("no")  |
           isMarried.equalsIgnoreCase("divorced"))
        {
            return true;
        }
        else
        {
            throw new IllegalArgumentException(("Marriage status is invalid"));
        }
    }

    /**
     * Prints persons detail in a string format.
     */
    public final void printDetails()
    {
        System.out.printf("%s %s (%s) was bor in %d, weighs %.1f pounds and has a %s degree! \n",
                          getFirstName(),
                          getLastName(),
                          getIsMarried(isMarried),
                          getBirthYear(),
                          getWeightInPounds(),
                          getHighestEducationLevel());
    }

    /**
     * Print detail of the person's details in a string format. Converts the weight of pounds to KG if the boolean
     * true is passed in. This method is overloaded
     * @param kilograms Converted to kilograms from pounds.
     */
    public final void printDetails(final boolean kilograms)
    {
        if(kilograms)
        {
            double weightInKg = getWeightInPounds() * LBS_TO_KG;

            System.out.printf("%s %s (%s) was bor in %d, weighs %.1f pounds and has a %s degree! \n",
                    getFirstName(),
                    getLastName(),
                    getIsMarried(isMarried),
                    getBirthYear(),
                    weightInKg,
                    getHighestEducationLevel());
        }
    }

    /***
     * This prints the person's information in a string format and converts to kilograms from pounds if the boolean is
     * true passed in, it changes the persons name to uppercase as well. It is printed in lower case and the
     * weight is in pounds if it is not.
     * @param kilograms Converted to kilograms from pounds.
     * @param uppercase Changes to uppercase if condition is met.
     */
    public final void printDetails(final boolean kilograms, final boolean uppercase)
    {
        if(kilograms && uppercase)
        {
            double weightInKg = getWeightInPounds() * LBS_TO_KG;
            System.out.printf("%s %s (%s) was born in %d, weighs %.1f pounds and has a %s degree! \n",
                            getFirstName().toUpperCase(),
                            getLastName().toUpperCase(),
                            getIsMarried(isMarried),
                            getBirthYear(),
                            weightInKg,
                            getHighestEducationLevel());
            }
            else if(kilograms)
            {
                double weightInKg = getWeightInPounds() * LBS_TO_KG;
                System.out.printf("%s %s (%s) was born in %d, weighs %.1f pounds and has a %s degree! \n",
                                getFirstName().toLowerCase(),
                                getLastName().toLowerCase(),
                                getIsMarried(isMarried),
                                getBirthYear(),
                                weightInKg,
                                getHighestEducationLevel());
            }
            else if(uppercase)
            {
                System.out.printf("%s %s (%s) was born in %d, weighs %.1f pounds and has a %s degree! \n",
                                getFirstName().toUpperCase(),
                                getLastName().toUpperCase(),
                                getIsMarried(isMarried),
                                getBirthYear(),
                                getWeightInPounds(),
                                getHighestEducationLevel());
            }
            else
            {
                System.out.printf("%s %s (%s) was born in %d, weighs %.1f pounds and has a %s degree! \n",
                                  getFirstName().toLowerCase(),
                                  getLastName().toLowerCase(),
                                  getIsMarried(isMarried),
                                  getBirthYear(),
                                  getWeightInPounds(),
                                  getHighestEducationLevel());
            }

    }

    /**
     * Persons information and prints their details.
     */
    public static void main(final String[] args)
    {
        try
        {
            Person p1;
            Person p2;
            Person p3;

            p1 = new Person(
                    "Tiger",
                    "Woods",
                    1975,
                    "divorced",
                    200,
                    "undergraduate");

            p1.printDetails();
            p1.printDetails(true);
            p1.printDetails(true, true);
            p1.printDetails(true, false);
            p1.printDetails(false, true);
            p1.printDetails(false, false);

            p2 = new Person(
                    "Jason",
                    "Wilder",
                    2000,
                    "no",
                    180,
                    "graduate");

            p2.printDetails();
            p2.printDetails(true);
            p2.printDetails(true, true);
            p2.printDetails(true, false);
            p2.printDetails(false, true);
            p2.printDetails(false, false);

            p3 = new Person(
                    "Santa",
                    "Claus",
                    1000,
                    "yes",
                    280,
                    "high school");

            p3.printDetails();
            p3.printDetails(true);
            p3.printDetails(true, true);
            p3.printDetails(true, false);
            p3.printDetails(false, true);
            p3.printDetails(false, false);
        }
        catch(final IllegalArgumentException e)
        {
            System.out.println(e.getMessage());
        }
    }
}
