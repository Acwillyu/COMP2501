package ca.comp2501.lab02a;

public class BankAccount
{
    private double balanceCad;

    private final String accountNumber;

    private final String memberLastName;

    /**
     * Gets the balance of the account in canadian dollars
     * @param balanceCad Balance in canadian dollars
     * @param accountNumber Customer's account number
     * @param memberLastName Customer''s last name
     */
    public BankAccount(final double balanceCad,
                       final String accountNumber,
                       final String memberLastName)
    {
        this.balanceCad = balanceCad;
        this.accountNumber = accountNumber;
        this.memberLastName = memberLastName;
    }

    /**
     * Constructor
     * @return Customer's last name
     */
    public String getMemberLastName()
    {
        return this.memberLastName;
    }

    /**
     * Takes out from the bank account in canadian dollars
     * @param amountCad Amount in canadian
     */
    public void withdraw(final double amountCad)
    {
        this.balanceCad -= amountCad;
    }

    /**
     * Deposits to another account in Canadian dollars
     * @param amountCad Amount in Canadian dollars
     */
    public void deposit(final double amountCad)
    {
        this.balanceCad += amountCad;
    }

    /**
     * Deposits Canadian dollars from one account to a different one
     * @param amountCad Amount in Canadian Dollars
     * @param account Customer's account number
     */
    public void transfer(final double amountCad,
                         final BankAccount account)
    {
        account.deposit(amountCad);
        this.withdraw(amountCad);
    }

    /**
     * Shows the balance of the account in Canadian Dollars
     * @return Balance in Canadian Dollars
     */
    public double getBalanceCad()
    {
        return this.balanceCad;
    }

    /**
     * Gets the account number of the customer
     * @return Customer's account number
     */
    public String getAccountNumber()
    {
        return this.accountNumber;
    }
}
