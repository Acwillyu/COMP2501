package ca.comp2501.lab02a;

import java.util.HashMap;
import java.util.Map;


public class bank
{
    private final String name;
    private final Map<String, BankAccount> accounts;

    public bank(String bankName)
    {
        this.name = bankName;
        accounts = new HashMap<>();
    }

    /**
     * Adds a customer's account
     * @param account New customer's account
     */
    public void addAccount(final BankAccount account)
    {
        this.accounts.put(account.getAccountNumber(), account);
    }

    /**
     * Gets the account number of the customer
     * @param accountNumber Account number of customer
     * @return Account number of customer
     */
    public BankAccount getAccount(final String accountNumber)
    {
        return this.accounts.get(accountNumber);
    }

    /**
     * Not in use at the moment
     * Removes customer's account if necessary
     * @param accountNumber Account number of customer
     */
    public void removeAccount(String accountNumber)
    {
        this.accounts.remove(accountNumber);
    }

    /**
     * Not in use at moment
     * Total number of accounts in the bank
     * @return Total of accounts in the bank
     */
    public int getNumberOfAccounts()
    {
        return this.accounts.size();
    }

    /**
     * Gets total balance of an account
     * @return total balance of the accounts
     */
    public double getTotalAccountsBalance()
    {
        double totalBalance = 0.0;
        for (BankAccount account : this.accounts.values())
        {
            totalBalance += account.getBalanceCad();
        }
        return totalBalance;
    }

    /**
     * Customer's account number and balance in canadian
     * @param amountCad Amount in canadian
     * @param accountNumber Customer's account number
     */
    public void depositTo(final double amountCad,
                          final String accountNumber)
    {
        this.accounts.get(accountNumber).deposit(amountCad);
    }

    /**
     * Prints all data in the account along with total balances
     */
    public void printAllCustomerData() {
        for (BankAccount account : this.accounts.values())
        {
            System.out.printf("Customer %s has $%.2f in account #%s\n",
                    account.getMemberLastName().substring(0, 1).toUpperCase() +
                            account.getMemberLastName().substring(1), account.getBalanceCad(),
                    account.getAccountNumber());
        }
        System.out.printf("Total bank balance in all accounts for %s is %.2f", this.name, getTotalAccountsBalance());
    }
}
