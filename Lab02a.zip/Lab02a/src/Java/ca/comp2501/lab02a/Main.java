package ca.comp2501.lab02a;
/**
 * Creates a BankAccount and prints the amounts of those users current bank amount
 * @author William Yu, Erik Lagman, Ethan Newtown
 * @Version 1.0
*/

public class Main
{
    public static void main(final String[] args)
    {
        bank bank;

        BankAccount acc1;
        BankAccount acc2;
        BankAccount acc3;
        BankAccount acc4;

        bank = new bank("bank of Kanada");

        acc1 = new BankAccount(100.0,"abc111","woods");
        acc2 = new BankAccount(200.0,"def222", "gates");
        acc3 = new BankAccount(300.0,"ghi333", "bezos");
        acc4 = new BankAccount(400.0, "jk1444", "zuckerberg");

        bank.addAccount(acc1);
        bank.addAccount(acc2);
        bank.addAccount(acc3);
        bank.addAccount(acc4);

        bank.depositTo(22.22, "def222");
        bank.getAccount("abc111").transfer(5.00, bank.getAccount("ghi333"));
        bank.printAllCustomerData();

    }
}
