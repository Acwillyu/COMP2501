package ca.comp2501.lab1b;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Calendar
{
    private final ArrayList<Integer> years;
    private final String[] months;
    private final ArrayList<Integer> days;
    private final HashMap<Integer, Date> dates;

    /**
     * Calender constructor and the ranges
     */
    public Calendar()
    {
        years = new ArrayList<>();
        for (int year = 1910; year <= 2025; year++)
            years.add(year);
        months = new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September",
                "October", "November", "December"};
        days = new ArrayList<>();
        dates = new HashMap<>();

        for (int day = 1; day <= 30; day++)
            days.add(day);
        int loopCount = 1;

        for(int year: years)
        {
            for(int m = 0; m < months.length; m++)
            {
                Iterator<Integer> it = days.iterator();
                while(it.hasNext())
                {
                    int day = it.next();
                    dates.put(loopCount, new Date(day, months[m], year));
                    loopCount++;
                }
            }
        }
    }

    /**
     * Prints out the dates specified
     */
    public void printCalendar()
    {
        for(int key: dates.keySet())
        {
            System.out.print(key + ": " + dates.get(key).getDate() + "\n");
        }
    }
}
