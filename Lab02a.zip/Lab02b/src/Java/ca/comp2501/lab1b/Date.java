package ca.comp2501.lab1b;

public class Date
{
    // Instance Variables
    private final int day;
    private final String month;
    private final int year;

    /**
     * Returns the day, month and year entered
     * @param day day of the week entered
     * @param month month of the year entered
     * @param year year entered
     */
    public Date(final int day, final String month, final int year)
    {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    /**
     * Day of the month entered
     * @return the day
     */
    public int getDay()
    {
        return day;
    }

    /**
     * The month entered
     * @return the month
     */
    public String getMonth()
    {
        return month;
    }

    /**
     * Year entered
     * @return Year
     */
    public int getYear()
    {
        return year;
    }

    /**
     * Day, month and year combined
     * @return Day,month and year in that order
     */
    public String getDate()
    {
        return getDay() + " " + getMonth() + ", " + getYear();
    }
}
