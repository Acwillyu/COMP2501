package ca.comp2501.lab1b;

/**
 * Prints out the specified dates
 * @author William Yu, Ethan Newtown, Erik Lagman
 */

public class Main
{
    public static void main(final String[] args)
    {
        Calendar calendar = new Calendar();

        calendar.printCalendar();
    }
}
