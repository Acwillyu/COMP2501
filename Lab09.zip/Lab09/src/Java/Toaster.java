public class Toaster extends Appliance
{
    private final int numOfSlots;
    private final boolean hasBagelSetting;

    private static final int MIN_NUM_OF_SLOTS = 1;
    private static final int MAX_NUM_OF_SLOTS = 8;

    public Toaster(final String  brand,
                   final String  color,
                   final double  weightInKg,
                   final int     manufactureYear,
                   final int     numOfSlots,
                   final boolean hasBagelSetting)
    {
        super(brand, color, weightInKg, manufactureYear);

        if(!isValidNumOfSlots(numOfSlots))
        {
            throw new IllegalArgumentException("The number of slots is not supported. " +
                                 "Please enter a number of slots between " + MIN_NUM_OF_SLOTS + MAX_NUM_OF_SLOTS);
        }

        this.numOfSlots = numOfSlots;
        this.hasBagelSetting = hasBagelSetting;
    }

    /**
     * @param numOfSlots Number of slots in the toaster.
     * @return Slots in the toaster.
     */
    private static boolean isValidNumOfSlots(final int numOfSlots)
    {
        return numOfSlots >= MIN_NUM_OF_SLOTS && numOfSlots <= MAX_NUM_OF_SLOTS;
    }

    @Override
    public String toString() {
        return "Toaster(" +
                "Brand:" + getBrand() +
                ", Color:" + getColor() +
                ", Weight In Kg:" + getWeightInKg() +
                ", Manufacture Year:" + getManufactureYear() +
                ", Number Of Slots:" + numOfSlots +
                ", Bagel Setting:" + hasBagelSetting +
                ")";
    }
}
