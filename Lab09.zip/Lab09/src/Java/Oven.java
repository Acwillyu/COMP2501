public class Oven extends Appliance
{
    private final String ovenType;
    private final int    numOfRacks;

    private static final int MIN_NUM_OF_RACKS = 1;
    private static final int MAX_NUM_OF_RACKS = 4;

    public Oven(final String brand,
                final String color,
                final double weightInKg,
                final int    manufactureYear,
                final String ovenType,
                final int    numOfRacks)
    {
        super(brand, color, weightInKg, manufactureYear);
        if(!isValidNumOfRacks(numOfRacks))
        {
            throw new IllegalArgumentException("The number of racks is not allowed. " +
                                  "Please enter a number between " + MIN_NUM_OF_RACKS + " and " + MAX_NUM_OF_RACKS);
        }
        if(!isValidOvenType(ovenType))
        {
            throw new IllegalArgumentException("The oven type is not supported. Currently the only supported " +
                                               "types are: conventional, convection or toaster");
        }
        this.numOfRacks = numOfRacks;
        this.ovenType = ovenType;
    }

    /**
     * @param numOfRacks Number of racks in the oven.
     * @return How many oven racks in the oven. Amount between 1 and 4.
     */
    private static boolean isValidNumOfRacks(final int numOfRacks)
    {
        return numOfRacks >= MIN_NUM_OF_RACKS &&
               numOfRacks <= MAX_NUM_OF_RACKS;
    }

    /**
     * @param ovenType One of three oven types.
     * @return Oven type of conventional, convection or toaster.
     */
    private static boolean isValidOvenType(final String ovenType)
    {
        final String comparedType;
        comparedType = ovenType.toLowerCase();

        return comparedType.equals("conventional") ||
               comparedType.equals("convection") ||
               comparedType.equals("toaster");
    }

    @Override
    public String toString() {
        return "Oven(" +
                "Brand: " + getBrand() +
                ", Color: " + getColor() +
                ", Weight In Kg: " + getWeightInKg() +
                ", Manufacture Year: " + getManufactureYear() +
                ", Oven Type: " + ovenType +
                ", Number Of Racks: " + numOfRacks +
                ")";
    }
}
