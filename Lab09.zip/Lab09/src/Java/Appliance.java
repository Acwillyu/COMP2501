/**
 * This class represents an Appliance
 * @author William Yu, Ethan Newton, Jezer Legman
 * @version 1.0
 */
public class Appliance
{
    private final String brand;
    private final String color;
    private final double weightInKg;
    private final int    manufactureYear;

    private static final int     MIN_STRING_LENGTH = 1;
    private static final int     MAX_STRING_LENGTH = 20;
    private static final double  MIN_WEIGHT_IN_KG = 0.1;
    private static final double  MAX_WEIGHT_IN_KG = 200.0;
    private static final int     EARLIEST_MANUFACTURE_YEAR = 1900;
    private static final int     LATEST_MANUFACTURE_YEAR = 2023;

    /**
     * Constructor for the Appliance class.
     * @param brand The brand of the appliance.
     * @param color The color of the appliance.
     * @param weightInKg The weight of the appliance in kg.
     * @param manufactureYear The year the appliance was manufactured.
     * @throws IllegalArgumentException if any parameter does not meet the requirements.
     */
    public Appliance(final String brand,
                     final String color,
                     final double weightInKg,
                     final int manufactureYear)
    {
        if(!isValidString(brand))
        {
            throw new IllegalArgumentException("String length must be within "
                    + MIN_STRING_LENGTH + " and " + MAX_STRING_LENGTH);
        }
        if(!isValidString(color))
        {
            throw new IllegalArgumentException("String length must be within "
                    + MIN_STRING_LENGTH + " and"  + MAX_STRING_LENGTH);
        }
        if(!isValidWeight(weightInKg))
        {
            throw new IllegalArgumentException("Weight must be within "
                    + MIN_WEIGHT_IN_KG + " and " + MAX_WEIGHT_IN_KG);
        }
        if(!isValidYear(manufactureYear))
        {
            throw new IllegalArgumentException("Year must be within "
                    + EARLIEST_MANUFACTURE_YEAR + " and " + LATEST_MANUFACTURE_YEAR);
        }
        this.brand = brand;
        this.color = color;
        this.weightInKg = weightInKg;
        this.manufactureYear = manufactureYear;
    }

    /**
     * Returns the brand of the appliance.
     */
    public String getBrand()
    {
        return brand;
    }

    /**
     * Returns the color of the appliance.
     */
    public String getColor()
    {
        return color;
    }

    /**
     * Returns the weight of this appliance in kilograms.
     */
    public double getWeightInKg()
    {
        return weightInKg;
    }

    /**
     * Returns the year the appliance was manufactured.
     */
    public int getManufactureYear()
    {
        return manufactureYear;
    }

    /**
     * Checks if the provided string is valid based on the requirements.
     * @param string the string to check.
     * @return true if the string is not null and its length is between MIN_STRING_LENGTH and MAX_STRING_LENGTH.
     */
    public static boolean isValidString(final String string)
    {
        if(string == null)
        {
            return false;
        }
        return string.length() >= MIN_STRING_LENGTH && string.length() <= MAX_STRING_LENGTH;
    }

    /**
     * Checks if the provided weight is valid based on the requirements.
     * @param weight the weight to check.
     * @return true if the weight is between MIN_WEIGHT_IN_KG and MAX_WEIGHT_IN_KG.
     */
    public static boolean isValidWeight(final double weight)
    {
        return weight >= MIN_WEIGHT_IN_KG && weight <= MAX_WEIGHT_IN_KG;
    }

    /**
     * Checks if the provided year is valid based on the requirements.
     * @param age the year to check.
     * @return true if the year is between EARLIEST_MANUFACTURE_YEAR and LATEST_MANUFACTURE_YEAR.
     */
    public static boolean isValidYear(final int age)
    {
        return age >= EARLIEST_MANUFACTURE_YEAR && age <= LATEST_MANUFACTURE_YEAR;
    }
}
