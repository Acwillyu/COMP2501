public class Microwave extends Appliance
{
    private final double  capacityInCubicFeet;
    private final boolean popcornFunction;

    private static final double MIN_CAPACITY_IN_CUBIC_FEET = 0.5;
    private static final double MAX_CAPACITY_IN_CUBIC_FEET = 2.5;

    public Microwave(final String  brand,
                     final String  color,
                     final double  weightInKg,
                     final int     manufactureYear,
                     final double  capacityInCubicFeet,
                     final boolean popcornFunction)
    {
        super(brand, color, weightInKg, manufactureYear);
        if(!isValidCapacity(capacityInCubicFeet))
        {
            throw new IllegalArgumentException("The capacity is not allowed. Please enter a number between "
                                                + MIN_CAPACITY_IN_CUBIC_FEET + MAX_CAPACITY_IN_CUBIC_FEET);
        }
        this.capacityInCubicFeet = capacityInCubicFeet;
        this.popcornFunction = popcornFunction;
    }

    /**
     * @param capacityInCubicFeet Capacity of the microwave in cubic feet.
     * @return Capacity of the microwave in cubic feet if it's range.
     */
    private static boolean isValidCapacity(final double capacityInCubicFeet)
    {
        return !(capacityInCubicFeet < MIN_CAPACITY_IN_CUBIC_FEET) &&
               !(capacityInCubicFeet > MAX_CAPACITY_IN_CUBIC_FEET);
    }

    @Override
    public String toString() {
        return "Microwave(" +
                "Brand: " + getBrand() +
                ", Color: " + getColor() +
                ", Weight In Kg: " + getWeightInKg() +
                ", Manufacture Year: " + getManufactureYear() +
                ", Capacity In Cubic Feet: " + capacityInCubicFeet +
                ", Popcorn Function: " + popcornFunction +
                ")";
    }
}
