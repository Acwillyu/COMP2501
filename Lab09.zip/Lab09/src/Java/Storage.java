import java.util.*;

public class Storage
{
    private final List<Appliance> applianceList;

    public Storage()
    {
        this.applianceList = new ArrayList<>();
    }

    public void addAppliance(Appliance appliance)
    {
        applianceList.add(appliance);
    }

    public void removeAppliance(Appliance appliance)
    {
        applianceList.remove(appliance);
    }

    public void displayAppliances()
    {
        for(Appliance appliance:applianceList)
        {
            System.out.println(appliance);
        }
    }

    public int getNumberOfAppliances()
    {
        return applianceList.size();
    }
}
