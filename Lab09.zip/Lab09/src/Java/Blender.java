public class Blender extends Appliance
{
    private final double capacityInLiters;
    private final boolean hasBoostMode;

    public static final double MIN_CAPACITY_IN_LITERS = 0.6;
    public static final double MAX_CAPACITY_IN_LITERS = 3.8;

    public Blender(final String  brand,
                   final String  color,
                   final double  weightInKg,
                   final int     manufactureYear,
                   final double  capacityInLiters,
                   final boolean hasBoostMode)
    {
        super(brand, color, weightInKg, manufactureYear);
        if(!isValidCapacityInLiters(capacityInLiters))
        {
            throw new IllegalArgumentException("The capacity you have entered is not allowed. " +
                                    "Please enter a number between " + MIN_CAPACITY_IN_LITERS + MAX_CAPACITY_IN_LITERS);
        }

        this.capacityInLiters = capacityInLiters;
        this.hasBoostMode = hasBoostMode;
    }

    /**
     * @param capacityInLiters Capacity of blender in liters.
     * @return Capacity of blender between 0.6 and 3.8 liters.
     */
    public boolean isValidCapacityInLiters(final double capacityInLiters)
    {
        return capacityInLiters >= MIN_CAPACITY_IN_LITERS &&
               capacityInLiters <= MAX_CAPACITY_IN_LITERS;
    }

    @Override
    public String toString() {
        return "Blender(" +
                "Brand:" + getBrand() +
                ", Color:" + getColor() +
                ", Weight In Kg:" + getWeightInKg() +
                ", Manufacture Year:" + getManufactureYear() +
                ", Capacity In Liters:" + capacityInLiters +
                ", Boost Mode:" + hasBoostMode +
                ")";
    }
}
