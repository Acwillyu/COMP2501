public class Driver
{
    public static void main(final String[] args)
    {
        Storage storage;
        storage  = new Storage();

        Fridge f1    = new Fridge("North Star","White",200.0, 2023, true, true);
        Oven o1      = new Oven("Samsung","Grey",90.9,2023,"convection",3);
        Microwave m1 = new Microwave("Panasonic","Black",30.5,1999,1.5, true);
        Toaster t1   = new Toaster("Toasty","Red",10.0,2022,2, false);
        Blender b1   = new Blender("Blendo","Black",11.0, 2021,3.5, true);

        storage.addAppliance(f1);
        storage.addAppliance(o1);
        storage.addAppliance(m1);
        storage.addAppliance(t1);
        storage.addAppliance(b1);

        storage.displayAppliances();

        System.out.println("There are " + storage.getNumberOfAppliances() + " appliances in storage");

        storage.removeAppliance(b1);

        storage.displayAppliances();

        System.out.println("There are " + storage.getNumberOfAppliances() + " appliances in storage");
    }
}
