public class Fridge extends Appliance
{
    private final boolean hasIceMaker;
    private final boolean hasFreezer;

    public Fridge(final String  brand,
                  final String  color,
                  final double  weightInKg,
                  final int     manufactureYear,
                  final boolean hasIceMaker,
                  final boolean hasFreezer)
    {
        super(brand, color, weightInKg, manufactureYear);
        this.hasIceMaker = hasIceMaker;
        this.hasFreezer  = hasFreezer;
    }

    @Override
    public String toString() {
        return "Fridge(" +
                "Brand: " + getBrand() +
                ", Color: " + getColor() +
                ", weightInKg: " + getWeightInKg() +
                ", Manufacture Year: " + getManufactureYear() +
                ", Ice Maker: " + hasIceMaker +
                ", Freezer: " + hasFreezer +
                ")";
    }
}
