package profile;

/**
 * This class models a particular calendar date using the Year, Month and Day as instance variables.
 */
public class Date
{
    // data set to private to prevent changes
    private final String Year;
    private final String Month;
    private final String Day;

    /**
     * A method to construct a calendar Date object using the following instance variables.
     * @param Year four character String
     * @param Month two character String
     * @param Day two character String
     */
    public Date(final String Year, final String Month, final String Day)
    {
        this.Year = Year;
        this.Month = Month;
        this.Day = Day;
    }

    /**
     * A method to return a year.
     * @return Year String
     */
    public String getYear()
    {
        return this.Year;
    }

    /**
     * A method to return a month.
     * @return Month String
     */
    public String getMonth()
    {
        return this.Month;
    }

    /**
     * A method to return a day.
     * @return Day String
     */
    public String getDay()
    {
        return this.Day;
    }

    /**
     * A method to return a calendar date in the format YYYY-MM-DD.
     * @return YYYY-MM-DD String
     */
    public String getYyMmDd()
    {
        return getYear() + "-" + getMonth() + "-" + getDay();
    }
}
