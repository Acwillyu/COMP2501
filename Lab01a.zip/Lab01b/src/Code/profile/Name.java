package profile;

/**
 * This class models a student's name using the first and last name as instance variables.
 */
public class Name
{
    // data set to private to prevent changes
    private final String firstName;
    private final String lastName;

    /**
     * A method to construct a Name object using the following instance variables.
     * @param firstName String
     * @param lastName String
     */
    public Name(final String firstName, final String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * A method to return a first name.
     * @return first name String
     */
    public String getFirstName()
    {
        return this.firstName;
    }

    /**
     * A method to return a last name.
     * @return last name String
     */
    public String getLastName()
    {
        return this.lastName;
    }

    /**
     * A method to return a full name by concatenating the first and last name.
     * @return first name + last name String
     */
    public String getFullName()
    {
        return getFirstName()+ " " +getLastName();
    }

    /**
     * A method to return the initials of a name.
     * @return Capitalized first letter of both first and last names, separated by a "."
     */
    public String getInitials()
    {
        return this.firstName.toUpperCase().charAt(0) + "." + this.lastName.toUpperCase().charAt(0) + ".";
    }
}