package profile;

/**
 * This class models a student's information and uses their name, student number, date of birth and graduation
 * as instance variables.
 */
public class Student
{
    // data set to private to prevent changes
    private final Name  name;
    private final String  studentNumber;
    private final Date  dateOfBirth;
    private final boolean graduated;

    /**
     * A method to construct a Student object using the following instance variables.
     * @param name Name object.
     * @param studentNumber String
     * @param dateOfBirth Date object
     * @param graduated boolean value
     */
    public Student(final Name name, final String studentNumber, final Date dateOfBirth, final boolean graduated)
    {
        this.name = name;
        this.studentNumber = studentNumber;
        this.dateOfBirth = dateOfBirth;
        this.graduated = graduated;
    }

    /**
     * A method to return a name.
     * @return name String
     */
    public Name getName()
    {
        return this.name;
    }

    /**
     * A method to return a student number.
     * @return student number String
     */
    public String getStudentNumber()
    {
        return this.studentNumber;
    }

    /**
     * A method to return a date of birth.
     * @return date of birth String
     */
    public Date getDateOfBirth()
    {
        return this.dateOfBirth;
    }

    /**
     * A method to return the true or false value of the instance variable 'graduated'.
     * @return true or false
     */
    public boolean isGraduated()
    {
        return this.graduated;
    }
}