import profile.Student;
import profile.Name;
import profile.Date;

/**
 * This class creates two main Student objects and displays their name, initials, student number, date of birth,
 * and graduation.
 * @author Jezer Lagman, Ethan Newton, Will Yu, and Jesus Araujo
 */
public class Main
{
    public static void main(final String[] args)
    {
        Name n1;
        Name n2;
        Date d1;
        Date d2;
        Student s1;
        Student s2;

        n1 = new Name("Tiger", "Woods");
        n2 = new Name("Bill", "Gates");
        d1 = new Date("1975", "12", "30");
        d2 = new Date("1955", "10", "28");
        s1 = new Student(n1, "A00123456", d1, true);
        s2 = new Student(n1, "A00987654", d2, false);

        // if true, prints full name, initials, student number, date of birth, and 'The student has graduated.'
        // if false, prints full name, initials, student number, date of birth, and 'The student has not graduated.'
        if(s1.isGraduated())
        {
            System.out.println(s1.getName().getFullName()+" ("+s1.getName().getInitials()+") "+" (st#"+
                    s1.getStudentNumber()+")"+" was born on " +s1.getDateOfBirth().getYyMmDd()+
                    ". The student has graduated.");
        }
        else
        {
            System.out.println(s1.getName().getFullName()+" ("+s1.getName().getInitials()+")"+" (st#"+
                    s1.getStudentNumber()+")"+" was born on "+s1.getDateOfBirth().getYyMmDd()+
                    ". The student has not graduated.");
        }

        if(s2.isGraduated())
        {
            System.out.println(s2.getName().getFullName()+" ("+s2.getName().getInitials()+")"+" (st#"+
                    s2.getStudentNumber()+")"+" was born on " +s2.getDateOfBirth().getYyMmDd()+
                    ". The student has graduated.");
        }
        else
        {
            System.out.println(n2.getFullName()+" ("+n2.getInitials()+")"+" (st#"+s1.getStudentNumber()+")"+
                    " was born on "+s2.getDateOfBirth().getYyMmDd()+". The student has not graduated.");
        }
    }
}