package ca.comp2501.lab1a;

/**
 * This class models the details of a member bank account.
 */
public class BankAccount
{
    private final String memberLastName;
    private final String accountNumber;
    private double       balanceCad;

    /**
     * Constructs a member bank account.
     */
    public BankAccount(final double balanceCad, final String accountNumber, final String memberLastName)
    {
        this.balanceCad = balanceCad;
        this.accountNumber = accountNumber;
        this.memberLastName = memberLastName;
    }

    /**
     * A method to return a public version of the member last name while leaving the instance variable unchanged
     * @return public member last name
     */
    public String getMemberLastName()
    {
        return memberLastName;
    }

    /**
     * A method to return a public version of the account number while leaving the instance variable unchanged
     * @return public account number
     */
    public String getAccountNumber()
    {
        return accountNumber;
    }

    /**
     * A method to return a public version of the balance(CAD) while leaving the instance variable unchanged
     * @return public balance(CAD)
     */
    public double getBalanceCad()
    {
        return balanceCad;
    }

    /**
     * Withdraws an amount in canadian dollars (CAD).
     */
    public void withdraw(final double amountCad)
    {
        this.balanceCad -= amountCad;
    }

    /**
     * Deposits an amount in canadian dollars (CAD).
     */
    public void deposit(final double amountCad)
    {
        this.balanceCad += amountCad;
    }

    /**
     * Transfers an amount in canadian dollars (CAD).
     */
    public void transfer(final double amountCad, final BankAccount account)
    {
        withdraw(amountCad);
        account.deposit(amountCad);
    }
}