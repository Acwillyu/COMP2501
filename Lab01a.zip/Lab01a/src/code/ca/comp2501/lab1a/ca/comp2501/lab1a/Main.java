package ca.comp2501.lab1a;

/**
 * This class creates BankAccount objects and performs withdrawal, deposit, and transfer methods.
 *  * @author Will yu, Ethan Newton, Erik Lagman
 *  * @version 1.0
 */
public class Main
{
    public static void main(final String[] args)
    {
        BankAccount b1;
        BankAccount b2;

        b1 = new BankAccount(100.00, "abc123", "gates");
        b2 = new BankAccount(500.00, "xyz789","woods");

        // Withdraws amount(CAD) from b1 then prints the updated balance.
        System.out.println(b1.getBalanceCad());
        b1.withdraw(5.00);
        System.out.println(b1.getAccountNumber());
        System.out.println(b1.getBalanceCad());

        System.out.println("---");

        // Deposits amount(CAD) to b2 then prints the member last name and the new balance.
        System.out.println(b2.getBalanceCad());
        b2.deposit(23.00);
        System.out.println(b2.getMemberLastName());
        System.out.println(b2.getBalanceCad());

        System.out.println("---");

        // Transfers amount(CAD) from b1 to b2 then prints the updated balances.
        b1.transfer(50.00, b2);
        System.out.println(b1.getBalanceCad());
        System.out.println(b2.getBalanceCad());
    }
}