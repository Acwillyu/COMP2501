package ca.comp2501.lab6;

/**
 * This Class models a Star Wars name.
 * @author William Yu, Ethan Newton, Jezer Lagman, and Nancy Chen.
 * @version 1.0
 */
public class StarWarsName
{
    private static final int MIN_ARGS = 4;
    private static final int FIRST_NAME_INDEX      = 0;
    private static final int LAST_NAME_INDEX       = 1;
    private static final int MOM_MAIDEN_NAME_INDEX = 2;
    private static final int CITY_OF_BIRTH_INDEX   = 3;

    private final String starWarsNameData;

    /**
     * Constructor creates a Star Wars Name object.
     * @param starWarsNameData Four different strings separated by the "|" symbol.
     */
    public StarWarsName(final String starWarsNameData)
    {
        this.starWarsNameData = starWarsNameData;
    }

    /**
     * This method parses and splits the provided string to create and display a Star Wars full name.
     * @IllegalArgumentException When an incorrect number of words is provided on startup.
     */
    public void getStarWarsName()
    {
        String[] stringTokens   = starWarsNameData.split("\\|");
        if(stringTokens.length != MIN_ARGS)
        {
            throw new IllegalArgumentException("ERROR: incorrect number of words provided.");
        }
        else
        {

            String firstName;
            String lastName;
            String motherMaidenName;
            String cityOfBirth;

            firstName        = stringTokens[FIRST_NAME_INDEX];
            lastName         = stringTokens[LAST_NAME_INDEX];
            motherMaidenName = stringTokens[MOM_MAIDEN_NAME_INDEX];
            cityOfBirth      = stringTokens[CITY_OF_BIRTH_INDEX];

            String swFirstNameFirstLetter;
            String swFirstNamePart1;
            String swFirstNamePart2;
            String swLastNameFirstLetter;
            String swLastNamePart1;
            String swLastNamePart2;


            swFirstNameFirstLetter = firstName.substring(0, 1);
            swFirstNamePart1       = firstName.substring(1, 3);
            swFirstNamePart2       = lastName.substring(0, 2).toLowerCase();
            swLastNameFirstLetter  = motherMaidenName.substring(0, 1);
            swLastNamePart1        = motherMaidenName.substring(1, 2);
            swLastNamePart2        = cityOfBirth.substring(0, 3).toLowerCase();

            String completeFirstName;
            String completeLastName;

            completeFirstName = swFirstNameFirstLetter+swFirstNamePart1+swFirstNamePart2;
            completeLastName  = swLastNameFirstLetter+swLastNamePart1+swLastNamePart2;

            System.out.printf("Your Star Wars name is: %s %s", completeFirstName, completeLastName);
        }
    }

    /**
     * Creates a Star Wars Name object if the correct parameter is entered, otherwise throws an error.
     * @param args supplies command-line arguments as an array of String objects.
     */
    public static void main(final String[] args)
    {
        try
        {
            StarWarsName s1;
            s1 = new StarWarsName("William|Yu|Guangdong|China");
            s1.getStarWarsName();
        }
        catch(final IllegalArgumentException e)
        {
            System.out.println(e.getMessage());
        }
    }
}