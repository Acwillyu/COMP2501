package fifa;

/**
 * This class models FIFA soccer (football) players for various teams in this league.
 * @author William yu
 * @version 1.0
 */
public class SoccerPlayer
{
    private String  lastName;
    private boolean retired;
    private int     yearBorn;
    private double  heightCm;

    /**
     * Constructs objects
     */
    public SoccerPlayer(final String lastName, final boolean retired,
                        final int yearOfBirth, final double heightInCm)
    {
        System.out.println("Creating a soccer player object");

        this.lastName = lastName;
        this.retired = retired;
        this.yearBorn = yearOfBirth;
        this.heightCm = heightInCm;

    }

    /**
     * Makes this player kick a ball
     */
    void kick()
    {

        System.out.println("Makes this player kick a ball");
    }
}
