package fifa;

public class Main
{
    public static void main(final String[] args)
    {
        SoccerPlayer sp;

        sp = new SoccerPlayer("messi",false,1988,172 );
        // sp.lastName = "Yu";
        // System.out.println(sp.lastName);
        sp.kick();

        String st; // reference type; has BEHAVIORS
        st = "hello world";
        st.toUpperCase();

        int x; // primitive type; no behaviors
        x = 5;
    }
}
