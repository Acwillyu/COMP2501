package ca.comp2501.lab10;

/**
 * This class models Music Media.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 1.0
 */
public class MusicMedia
{
    private static final int    MIN_SONGS   = 1;
    private static final double MIN_RUNTIME = 1.0;
    private final String        musicalArtist;
    private final String        songTitle;
    private final int           totalNumSongs;
    private final int           totalMinutes;
    private final String        year;

    /**
     * This constructor creates a Music Media object.
     * @param musicalArtist The name of the musical artist.
     * @param songTitle     The title of the album.
     * @param totalNumSongs The total number of songs.
     * @param totalMinutes  The total runtime.
     * @param year          The year of release.
     */
    public MusicMedia(final String musicalArtist,
                      final String songTitle,
                      final int    totalNumSongs,
                      final int    totalMinutes,
                      final String year)
    {
        isValidStr(musicalArtist, "Musical Artist");
        isValidStr(songTitle, "Song title ");
        hasValidNumSongs(totalNumSongs);
        hasValidRuntime(totalMinutes);

        this.musicalArtist = musicalArtist;
        this.songTitle     = songTitle;
        this.totalNumSongs = totalNumSongs;
        this.totalMinutes  = totalMinutes;
        this.year          = year;
    }

    /**
     * @return The name of the musical artist.
     */
    public final String getMusicalArtist()
    {
        return musicalArtist;
    }

    /**
     * @return The album title.
     */
    public final String getSongTitle()
    {
        return songTitle;
    }

    /**
     * @return The total number of songs.
     */
    public final int getTotalNumSongs()
    {
        return totalNumSongs;
    }

    /**
     * @return The total runtime.
     */
    public final int getTotalMinutes()
    {
        return totalMinutes;
    }

    /**
     * @return The year of release.
     */
    public final String getYear()
    {
        return year;
    }

    /**
     * Display the selected song.
     * @return A formatted String of the song selection.
     */
    public String playSelection()
    {
        final String songSelection;
        songSelection = "Thank you for using our Music Library. \n";
        return songSelection;
    }

    /**
     * @return A String of the object information.
     */
    public String toString()
    {
        return  "Album [" +
                "Musical Artist= "          + getMusicalArtist() +
                ", Song Title= \""          + getSongTitle() + "\"" +
                ", Total Number of Songs= " + getTotalNumSongs() +
                ", Total Minutes= "         + getTotalMinutes() +
                "]\n";
    }

    /**
     * A method to validate a String.
     * @param strToValidate The String to be validated.
     * @param nameOfVariable The name of the variable.
     * @throws IllegalArgumentException If the String is null, empty, or blank.
     */
    private void isValidStr(final String strToValidate,
                            final String nameOfVariable)
    {
        if(strToValidate == null   ||
           strToValidate.isEmpty() ||
           strToValidate.isBlank())
        {
            throw new IllegalArgumentException("Music Media Error: " + nameOfVariable + " is missing.");
        }
    }

    /**
     * A method to validate an integer.
     * @param intToValidate The integer to be validated.
     * @throws IllegalArgumentException If the int is less than the minimum allowable number of songs.
     */
    private void hasValidNumSongs(final int intToValidate)
    {
        final String intErrorMessage;
        intErrorMessage = String.format("Music Media Error: Number of songs cannot be less than %d.", MIN_SONGS);

        if(intToValidate < MIN_SONGS)
        {
            throw new IllegalArgumentException(intErrorMessage);
        }
    }

    /**
     * A method to validate the total runtime.
     * @param totalRuntimeMinutes The length of the runtime in minutes.
     * @throws IllegalArgumentException If the total runtime is less than the minimum allowable runtime.
     */
    private void hasValidRuntime(final double totalRuntimeMinutes)
    {
        final String doubleErrorMessage;
        doubleErrorMessage = String.format("Total runtime minutes cannot be less than %.2f", MIN_RUNTIME);

        if(totalRuntimeMinutes < MIN_RUNTIME)
        {
            throw new IllegalArgumentException(doubleErrorMessage);
        }
    }
}
