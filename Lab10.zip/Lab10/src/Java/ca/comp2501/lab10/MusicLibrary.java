package ca.comp2501.lab10;

import java.util.List;
import java.util.ArrayList;

/**
 * This class models a Music Library.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 1.0
 */
public class MusicLibrary
{
    private final List<MusicMedia> albums;

    /**
     *Creates a Music Library ArrayList.
     */
    public MusicLibrary()
    {
        this.albums = new ArrayList<>();
    }

    /**
     * Add media to the Music Library.
     * @param media The media to be added.
     */
    public final void addMedia(final MusicMedia media)
    {
        if(media != null)
        {
            albums.add(media);
        }
    }

    /**
     * Display the Music Library details.
     */
    public final void displayLibrary()
    {
        for(MusicMedia album: albums)
        {
            System.out.print(album);
        }
    }

    /**
     *Play the chosen song title.
     * @param title The title of the song being searched.
     */
    public final void playTitle(final String title)
    {
        if(title != null &&
           !title.isBlank() &&
           !title.isEmpty())
        {
            for(MusicMedia song: albums)
            {
                if(title.equalsIgnoreCase(song.getSongTitle()))
                {
                    System.out.print(song.playSelection());
                }
            }
        }
        else
        {
            throw new IllegalArgumentException("Music Library Error: title cannot be null, empty, or blank.");
        }
    }
}
