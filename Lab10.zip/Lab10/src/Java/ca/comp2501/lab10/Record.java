package ca.comp2501.lab10;

/**
 * This class models a Record.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 1.0
 */
public class Record extends MusicMedia
{
    private static final int    SM_RECORD_INCHES = 7;
    private static final int    MD_RECORD_INCHES = 10;
    private static final int    LG_RECORD_INCHES = 12;
    private static final double LOW_RPM  = 33.3;
    private static final double MED_RPM  = 45.0;
    private static final double HIGH_RPM = 78.0;
    private final int           sizeInInches;
    private final double        rpm;

    /**
     * This constructor creates a Record Object.
     * @param musicalArtist The name of the musical artist.
     * @param songTitle     The title of the album.
     * @param totalNumSongs The total number of songs on the record.
     * @param totalMinutes  The total runtime of the record in minutes.
     * @param year          The year of the record.
     * @param sizeInInches    The size of the record in inches.
     * @param rpm           The rpm of the record.
     */
    public Record(final String musicalArtist,
                  final String songTitle,
                  final int    totalNumSongs,
                  final int    totalMinutes,
                  final String year,
                  final int    sizeInInches,
                  final double rpm)
    {
        super(musicalArtist, songTitle, totalNumSongs, totalMinutes, year);

        isValidSize(sizeInInches);
        hasValidRpm(rpm);

        this.sizeInInches = sizeInInches;
        this.rpm          = rpm;
    }

    /**
     * A method to get the size of the record in inches.
     * @return The size of the record in inches.
     */
    public final int getSizeInches()
    {
        return sizeInInches;
    }

    /**
     * A method to get the RPM of the record.
     * @return The record's RPM.
     */
    public final double getRpm()
    {
        return rpm;
    }

    /**
     * A method to validate the size of the record in inches.
     * @param sizeInches The size of the record in inches.
     * @throws IllegalArgumentException If the record does not match any of the size categories.
     * @return true if the size of the record is either small, medium or large.
     */
    private boolean isValidSize(final int sizeInches)
    {
        if(sizeInInches == SM_RECORD_INCHES ||
           sizeInInches == MD_RECORD_INCHES ||
           sizeInInches == LG_RECORD_INCHES)
        {
            return true;
        }
        throw new IllegalArgumentException("Record Error: Invalid record size.");
    }

    /**
     * A method to valid the rpm of the record.
     * @param rpm The rpm of the record.
     * @throws IllegalArgumentException If the record's rpm does not match any of the rpm categories.
     * @return true if the rpm is either low, medium or high rpm.
     */
    private boolean hasValidRpm(final double rpm)
    {
        if(rpm == LOW_RPM ||
           rpm == MED_RPM ||
           rpm == HIGH_RPM)
        {
            return true;
        }
        throw new IllegalArgumentException("Record Error: Invalid rpm.");
    }

    /**
     * @return A String of the object information.
     */
    @Override
    public String toString()
    {
        return  "Record [" +
                "Size="                               + getSizeInches() +
                ", rpm="                              + getRpm() +
                ", toString()=Album [Musical Artist=" + getMusicalArtist() +
                ", Song Title=\""                     + getSongTitle() + "\"" +
                ", Total Number of Songs="            + getTotalNumSongs() +
                ", Total Minutes="                    + getTotalMinutes() +
                "]]\n";
    }

    /**
     * @return A formatted String of the song details.
     */
    @Override
    public String playSelection()
    {
        final String songSelection;
        songSelection = "Thank you for using our Music Library. \n" +
                        "You have selected the record \"" + getSongTitle() + "\" by " + getMusicalArtist() + ".\n" +
                        "This is a " + getSizeInches() + " inch record from " + getYear() + ", playing at " + getRpm() +
                        " rpm.";

        return songSelection;
    }
}
