package ca.comp2501.lab10;

/**
 * This class models a Compact Disc.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 1.0
 */
public class CompactDisc extends MusicMedia
{
    private final boolean bonusTracks;
    private final boolean digitalPac;

    /**
     * This constructor creates a Compact Disc Object.
     * @param musicalArtist The name of the musical artist.
     * @param songTitle     The title of the song.
     * @param totalNumSongs The total number of songs.
     * @param totalMinutes  The total runtime in minutes.
     * @param year          The year of release.
     * @param bonusTracks   If the compact disc has bonus tracks.
     * @param digitalPac    If the compact disc comes in a digipac.
     */
    public CompactDisc(final String  musicalArtist,
                       final String  songTitle,
                       final int     totalNumSongs,
                       final int     totalMinutes,
                       final String  year,
                       final boolean bonusTracks,
                       final boolean digitalPac)
    {
        super(musicalArtist, songTitle, totalNumSongs, totalMinutes, year);
        this.bonusTracks    = bonusTracks;
        this.digitalPac     = digitalPac;
    }

    /**
     * A method to check for bonus tracks.
     * @return true if bonus tracks are present, otherwise false.
     */
    public final boolean hasBonusTracks()
    {
        return bonusTracks;
    }

    /**
     * A method to check if the compact disc comes in a digipac.
     * @return true if the compact disc comes in a digital, otherwise false.
     */
    public final boolean hasDigitalpac()
    {
        return digitalPac;
    }

    /**
     * A method to format the object information into a String.
     * @return A String of the object information.
     */
    @Override
    public String toString()
    {
        return  "CompactDisc [" +
                "Bonus Tracks="                       + hasBonusTracks() +
                ", Digitalpac="                       + hasDigitalpac() +
                ", toString()=Album [Musical Artist=" + getMusicalArtist() +
                ", Song Title=\""                     + getSongTitle() + "\"" +
                ", Total Number of Songs="            + getTotalNumSongs() +
                ", Total Minutes="                    + getTotalMinutes() +
                "]]\n";
    }

    /**
     * A method to display the details of the selected song.
     * @return A formatted String of the song details.
     */
    @Override
    public String playSelection()
    {
        final String songSelection;
        songSelection = "Thank you for using our Music Library. \n" +
                "You have selected the CD \"" + getSongTitle() + "\" by " + getMusicalArtist() + ".\n" +
                "This is a Compact Disc from the year " + getYear() + ".";

        return songSelection;
    }
}
