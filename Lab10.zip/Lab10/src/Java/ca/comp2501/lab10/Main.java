package ca.comp2501.lab10;

/**
 * This Class creates an objects and calls methods.
 * @author Jezer Lagman, Ethan Newton, Will Yu.
 * @version 1.0
 */
public class Main
{
    public static void main(final String[] args)
    {
        try
        {
            MusicMedia m1;
            m1 = new Record("The Beatles", "Hey Jude", 1, 7, "2023", 7, 45.0);

            MusicMedia m2;
            m2 = new CompactDisc("Neil Young & Crazy Horse", "Everybody Knows This Is Nowhere",
                                 4, 40, "1969", false, false);

            MusicMedia m3;
            m3 = new AudioFile("Donnie Iris and the Cruisers", "Ah Leah!", 1, 4, "2022", "m4a");

            MusicLibrary ml1;
            ml1 = new MusicLibrary();

            ml1.addMedia(m1);
            ml1.addMedia(m2);
            ml1.addMedia(m3);

            ml1.displayLibrary();
            System.out.print("\n\n");
            ml1.playTitle("Hey Jude");
            System.out.print("\n\n");
            ml1.playTitle("Everybody Knows This Is Nowhere");
            System.out.print("\n\n");
            ml1.playTitle("Ah Leah!");
            System.out.print("\n\n");
            ml1.playTitle(null); // Error test
        }
        catch(final IllegalArgumentException e)
        {
            System.out.print(e.getMessage());
        }
    }
}
