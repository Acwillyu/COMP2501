package ca.comp2501.lab10;

/**
 * This class models an Audio File.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 1.0
 */
public class AudioFile extends MusicMedia
{
    private final String fileType;

    /**
     * This constructor creates an Audio File Object.
     * @param musicalArtist The name of the musical artist.
     * @param songTitle     The title of the song.
     * @param totalNumSongs The total number of songs.
     * @param totalMinutes  The total runtime in minutes.
     * @param year          The year of release.
     * @param fileType      The file type of the Audio File.
     */
    public AudioFile(final String musicalArtist,
                     final String songTitle,
                     final int    totalNumSongs,
                     final int    totalMinutes,
                     final String year,
                     final String fileType)
    {
        super(musicalArtist, songTitle, totalNumSongs, totalMinutes, year);

        isValidFileType(fileType);

        this.fileType = fileType;
    }

    /**
     * @return The file type.
     */
    public final String getFileType()
    {
        return fileType;
    }

    /**
     * A method to validate the file type.
     * @param fileType The String to be validated.
     * @throws IllegalArgumentException If the String is null, empty, or blank.
     * @return true if the String is valid.
     */
    private boolean isValidFileType(final String fileType)
    {
        if(fileType.equalsIgnoreCase("mp3") ||
           fileType.equalsIgnoreCase("m4a") ||
           fileType.equalsIgnoreCase("wav"))
        {
            return true;
        }
        throw new IllegalArgumentException("Audio File Error: Invalid file type.");
    }

    /**
     * @return A String of the object information.
     */
    @Override
    public String toString()
    {
        return  "AudioFile [" +
                "File Type= "                         + getFileType() +
                ", toString()=Album [Musical Artist=" + getMusicalArtist() +
                ", Song Title=\""                     + getSongTitle() + "\"" +
                ", Total Number of Songs="            + getTotalNumSongs() +
                ", Total Minutes="                    + getTotalMinutes() +
                "]]\n";
    }

    /**
     * @return A formatted String of the song details.
     */
    @Override
    public String playSelection()
    {
        final String songSelection;
        songSelection = "Thank you for using our Music Library. \n" +
                        "You have selected the Audio File \"" + getSongTitle() + "\" by " + getMusicalArtist() + ".\n" +
                        "This file is in " + getFileType() + " format, from the year " + getYear() + ".";

        return songSelection;
    }
}
