package ca.comp2501.lab04;

/**
 * This Class extends an Exception when the substring entered is null.
 * @author William Yu,, Ethan Newton, Jezer Lagman, and Jesus Araujo.
 * @version 1.0
 */
public class IllegalNameException extends Exception
{
    IllegalNameException(final String errorMessage)
    {
        super(errorMessage);
    }
}
