package ca.comp2501.lab04;

/**
 * This Class extends a RuntimeException when the substring entered is not "author" or "title" in any letter casing.
 * @author William Yu,, Ethan Newton, Jezer Lagman, and Jesus Araujo.
 * @version 1.0
 */
public class IllegalNovelPropertyException extends RuntimeException
{
    IllegalNovelPropertyException(final String errorMessage)
    {
        super(errorMessage);
    }
}
