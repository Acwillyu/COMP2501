package ca.comp2501.lab07;
import java.util.ArrayList;
import java.util.List;

/**
 * This class models a hockey team.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 0.3
 */
public class Team
{
    private static final int LOWEST_POSSIBLE_STAT_VALUE = 0;
    private static final int SINGLE_STAT_VALUE          = 1;
    private final String teamName;
    private final String homeCity;

    private int    wins;
    private int    losses;
    private final  List<Player> players;

    public Team(final String teamName,
                final String homeCity,
                final int    wins,
                final int    losses)
    {
        isValidString(teamName, "Team name");
        isValidString(homeCity, "Home city");
        isValidInt(wins, "wins", LOWEST_POSSIBLE_STAT_VALUE);
        isValidInt(losses, "losses", LOWEST_POSSIBLE_STAT_VALUE);


        this.teamName      = teamName;
        this.homeCity      = homeCity;
        this.wins          = wins;
        this.losses        = losses;
        this.players       = new ArrayList<>();
    }

    /**
     * This method gets the team name.
     * @return The team name.
     */
    public String getTeamName()
    {
        return teamName;
    }

    /**
     * This method gets the name of the team's home city.
     * @return The name of the team's home city.
     */
    public String getHomeCity()
    {
        return homeCity;
    }

    /**
     * This method gets the number of wins.
     * @return The number of wins.
     */
    public int getWins()
    {
        return wins;
    }

    /**
     * This method gets the number of losses.
     * @return The number of losses.
     */
    public int getLosses()
    {
        return losses;
    }

    /**
     * This method adds a win to the team's record.
     */
    public void addWin()
    {
        this.wins += SINGLE_STAT_VALUE;
    }

    /**
     * This method adds a loss to the team's record.
     */
    public void addLoss()
    {
        this.losses += SINGLE_STAT_VALUE;
    }

    /**
     * This method adds a player to the team.
     * @param player The player to be added.
     */
    public void addPlayer(final Player player)
    {
        players.add(player);
    }

    /**
     * This method validates the String parameter.
     * @param strToValidate The String parameter that is being validated.
     * @param variableName The name of the variable.
     * @throws NullPointerException If the firstName parameter is null.
     * @throws IllegalArgumentException If the firstName parameter is blank or empty.
     * @return true if the first name is valid.
     */
    private boolean isValidString(final String strToValidate,
                                  final String variableName)
    {
        if(strToValidate == null)
        {
            throw new NullPointerException(variableName + " cannot be null.");
        }
        else if(strToValidate.isBlank() ||
                strToValidate.isEmpty())
        {
            throw new IllegalArgumentException(variableName + " missing.");
        }
        return true;
    }

    /**
     * This method validates the integer parameter.
     * @param intToValidate The integer parameter that is being validated.
     * @param variableName The name of the variable.
     * @throws IllegalArgumentException If the parameter is lower than the LOWEST_POSSIBLE_STAT_VALUE.
     * @return true if the parameter is valid.
     */
    private boolean isValidInt(final int intToValidate,
                               final String variableName,
                               final int minIntValue)
    {
        if(intToValidate < minIntValue)
        {
            throw new IllegalArgumentException("Team cannot have negative "+variableName+".");
        }
        return true;
    }
}
