package ca.comp2501.lab07;
import java.util.List;
import java.util.ArrayList;

/**
 * This class models a hockey league.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 0.3
 */
public class League
{
    private final String leagueName;
    private final List<Team> teams;

    public League(final String leagueName)
    {
        this.leagueName = leagueName;
        this.teams      = new ArrayList<>();

        isValidString(leagueName, "League name");
    }

    /**
     * This method validates the String parameter.
     * @param strToValidate The String parameter that is being validated.
     * @param variableName The name of the variable.
     * @throws NullPointerException If the firstName parameter is null.
     * @throws IllegalArgumentException If the firstName parameter is blank or empty.
     * @return true if the first name is valid.
     */
    private boolean isValidString(final String strToValidate,
                                  final String variableName)
    {
        if(strToValidate == null)
        {
            throw new NullPointerException(variableName + " cannot be null.");
        }
        else if(strToValidate.isBlank() ||
                strToValidate.isEmpty())
        {
            throw new IllegalArgumentException(variableName + " missing.");
        }
        return true;
    }

    /**
     * This method adds a team to the league.
     * @param team The team to be added.
     */
    public void addTeam(final Team team)
    {
        teams.add(team);
    }

    /**
     * This method gets the league name.
     * @return The league name.
     */
    public String getLeagueName()
    {
        return leagueName;
    }
}
