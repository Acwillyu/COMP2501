package ca.comp2501.lab07;

/**
 * This class models a hockey player.
 * @author William Yu, Jezer Lagman, Ethan Newton.
 * @version 0.3
 */
public class Player
{
    private static final int CURRENT_YEAR                 = 2023;
    private static final int HIGHEST_ALLOWABLE_JERSEY_NUM = 99;
    private static final int LOWEST_ALLOWABLE_JERSEY_NUM  = 1;
    private static final int MIN_ALLOWABLE_PLAYER_AGE     = 18;

    private final String firstName;
    private final String lastName;
    private final int    yearOfBirth;
    private String position;
    private int    jerseyNumber;



    /**
     * This constructor creates a Player object.
     * @param firstName The first name of the player.
     * @param lastName The last name of the player.
     * @param yearOfBirth The player's birth year.
     * @param position The player's team position.
     * @param jerseyNumber The player's jersey number.
     */
    public Player(final String firstName,
                  final String lastName,
                  final int    yearOfBirth,
                  final String position,
                  final int    jerseyNumber)
    {
        isValidString(firstName, "First name");
        isValidString(lastName, "Last name");
        isValidAge(yearOfBirth);
        isValidString(position, "Player position");
        isValidJerseyNumber(jerseyNumber);


        this.firstName    = firstName;
        this.lastName     = lastName;
        this.yearOfBirth  = yearOfBirth;
        this.position     = position;
        this.jerseyNumber = jerseyNumber;
    }

    /**
     * This method gets the player's first name.
     * @return The player's first name.
     */
    public String getFirstName()
    {
        return firstName;
    }

    /**
     * This method gets the player's last name.
     * @return The player's last name.
     */
    public String getLastName()
    {
        return lastName;
    }

    /**
     * This method gets the player's birth year.
     * @return The player's birth year.
     */
    public int getYearOfBirth()
    {
        return yearOfBirth;
    }

    /**
     * This method gets the player's position.
     * @return The player's position.
     */
    public String getPosition()
    {
        return position;
    }

    /**
     * This method gets the player's jersey number.
     * @return The player's jersey number.
     */
    public int getJerseyNumber()
    {
        return jerseyNumber;
    }

    /**
     * This method sets the player's jersey number.
     * @param jerseyNumber The player's jersey number.
     */
    public void setJerseyNumber(final int jerseyNumber)
    {
        this.jerseyNumber = jerseyNumber;
    }

    /**
     * This method sets the player's position.
     * @param position The player's position.
     */
    public void setPosition(final String position)
    {
        this.position = position;
    }

    /**
     * This method validates the String parameter.
     * @param strToValidate The String parameter that is being validated.
     * @param variableName The name of the variable.
     * @throws NullPointerException If the firstName parameter is null.
     * @throws IllegalArgumentException If the firstName parameter is blank or empty.
     * @return true if the first name is valid.
     */
    private boolean isValidString(final String strToValidate,
                                  final String variableName)
    {
        if(strToValidate == null)
        {
            throw new NullPointerException(variableName + " cannot be null.");
        }
        else if(strToValidate.isBlank() || strToValidate.isEmpty())
        {
            throw new IllegalArgumentException(variableName + " missing.");
        }
        return true;
    }

    /**
     * This method validates the player's age.
     * @param yearOfBirth The player's birth year.
     * @throws IllegalArgumentException If the player's age is less than minimum allowable player age.
     * @return true if the player's age is valid.
     */
    private boolean isValidAge(final int yearOfBirth)
    {
        if(CURRENT_YEAR - yearOfBirth < MIN_ALLOWABLE_PLAYER_AGE)
        {
            throw new IllegalArgumentException("Player is too young to be in the National Hockey League.");
        }
        return true;
    }

    /**
     * This method validates the player's jersey number.
     * @param jerseyNumber The player's jersey number.
     * @throws IllegalArgumentException If the player's jersey number is less than the lowest allowable jersey number,
     * or greater than the highest allowable jersey number.
     * @return true if the jersey number is valid.
     */
    private boolean isValidJerseyNumber(final int jerseyNumber)
    {
        if(jerseyNumber < LOWEST_ALLOWABLE_JERSEY_NUM ||
                jerseyNumber > HIGHEST_ALLOWABLE_JERSEY_NUM)
        {
            throw new IllegalArgumentException("Invalid jersey number");
        }
        return true;
    }
}

