package ca.comp2501.lab07;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PlayerTest
{
    Player p1;

    @BeforeEach
    void setUp()
    {
        p1 = new Player("william", "yu", 1995, "defence", 13);
    }

    @AfterEach
    void tearDown()
    {
        p1 = null;
    }

    @Test
    void getFirstName()
    {
        assertEquals("william", p1.getFirstName());
    }

    @Test
    void getLastName()
    {
        assertEquals("yu", p1.getLastName());
    }

    @Test
    void getYearOfBirth()
    {
        assertEquals(1995, p1.getYearOfBirth());
    }

    @Test
    void getPosition()
    {
        assertEquals("defence", p1.getPosition());
    }

    @Test
    void getJerseyNumber()
    {
        assertEquals(13, p1.getJerseyNumber());
    }
}