package ca.comp2501.lab07;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TeamTest
{

    Team t1;

    Player p1;
    Player p2;
    Player p3;
    Player p4;
    Player p5;


    @BeforeEach
    void setUp()
    {
        t1 = new Team("vancouver lumberjacks", "vancouver", 12, 7);

        p1 = new Player("william", "yu", 1995, "defence", 13);
        p2 = new Player("wayne", "gretzky", 1961, "center", 99);
        p3 = new Player("rob","dockett", 1981, "right wing", 88);
        p4 = new Player("don","cheeto", 1983, "left wing", 89);
        p5 = new Player("bobby","hill", 1997, "goalie", 90);
    }

    @AfterEach
    void tearDown()
    {
        t1 = null;
        p1 = null;
        p2 = null;
        p3 = null;
        p4 = null;
        p5 = null;
    }

    @Test
    void getTeamName()
    {
        assertEquals("vancouver lumberjacks", t1.getTeamName());
    }

    @Test
    void getHomeCity()
    {
        assertEquals("vancouver", t1.getHomeCity());
    }

    @Test
    void getWins()
    {
        assertEquals(12, t1.getWins());
    }

    @Test
    void getLosses()
    {
        assertEquals(7, t1.getLosses());
    }
}