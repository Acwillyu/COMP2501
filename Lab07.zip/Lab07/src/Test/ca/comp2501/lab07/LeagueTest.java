package ca.comp2501.lab07;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LeagueTest
{
    League l1;
    @BeforeEach
    void setUp()
    {
        l1 = new League("nhl");
    }

    @AfterEach
    void tearDown()
    {
        l1 = null;
    }

    @Test
    void getLeagueName()
    {
        assertEquals("nhl", l1.getLeagueName());
    }
}